About GP4Configurator:
==============================

This configurator is a GUI based program that performs very similarly in allowing you to change internal settings of the game.
The program is still in it's first days, so expect it to not be extremely user friendly.


How it works:
=============

Just run the program after copying it to your user directory. Example: C:\Users\MyName\Release
After making all necessary changes and generating the configuration file, copy the newly generated file to your GP4 installation directory.
The program creates a backup file everytime you run it (f1graphics.cfg.backup), so in case of any misconfigurations you can always copy the original backup to your GP4 installation directory.


What to know:
=============

This program is an unofficial program. It is completely free and does not give any sort of guarantee to the user using it. It is under your own discretion to use the program.
There is no copyright attached, and you can use the program as you like and I do not really mind about it.


Community:
==========

The program is deployed on git for community based contributions - https://github.com/vijaykanta/gp4_app.git
The program is also deployed on Aaditas, a website where you can complete your programs - http://www.aaditas.com/
The community program is only intended to make you people come up with your own versions.



~Vijay Kanta. aka Viz aka Vizu. :-)
